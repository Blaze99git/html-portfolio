def evaluate_rules(alert, trends, rules):
    matched = []

    metrics = {}
    for t in trends:
        metrics.setdefault(t["metric"], []).append(float(t["value"]))

    def high(metric, threshold=75):
        return max(metrics.get(metric, [0])) > threshold

    for rule in rules:
        cond = rule["condition"]
        if (
            ("hot_air_flow_high" in cond and high("hot_air_flow")) and
            ("motor_temperature_high" in cond and high("motor_temperature")) or
            ("cold_air_flow_low" in cond and not high("cold_air_flow", 30))
        ):
            matched.append(rule)

    return matched
