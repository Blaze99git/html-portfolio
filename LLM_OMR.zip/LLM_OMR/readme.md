The Ollama API is now available at 127.0.0.1:11434.
