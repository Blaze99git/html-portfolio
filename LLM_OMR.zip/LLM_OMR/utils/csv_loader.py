import csv

def load_csv(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))
