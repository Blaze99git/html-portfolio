import requests
import json

OLLAMA_URL = "http://localhost:11434/api/generate"
MODEL = "phi3:mini"

def ask_ollama(alert_name, asset_id, trends):
    prompt = f"""
You are an industrial diagnostics expert.

Alert:
- Name: {alert_name}
- Asset: {asset_id}

Trend data (time ordered):
{json.dumps(trends, indent=2)}

TASK:
1. Infer the most likely root cause.
2. Justify using ONLY the trend patterns.
3. Recommend a practical maintenance fix.

RULES:
- Use industrial reasoning.
- Do NOT invent sensors.
- Return ONLY valid JSON.
- No markdown. No explanations outside JSON.

JSON FORMAT:
{{
  "root_cause": "...",
  "evidence": ["...", "..."],
  "recommended_fix": "...",
  "confidence": 0.0
}}
"""

    resp = requests.post(
        OLLAMA_URL,
        json={
            "model": MODEL,
            "prompt": prompt,
            "stream": False
        },
        timeout=120
    )

    # ---- HTTP-level check ----
    if resp.status_code != 200:
        raise RuntimeError(f"Ollama HTTP error {resp.status_code}: {resp.text}")

    data = resp.json()

    # ---- Ollama-level error ----
    if "error" in data:
        raise RuntimeError(f"Ollama error: {data['error']}")

    if "response" not in data:
        raise RuntimeError(f"Unexpected Ollama response format: {data}")

    raw_text = data["response"].strip()

    # ---- JSON parse from model output ----
    try:
        return json.loads(raw_text)
    except json.JSONDecodeError as e:
        raise RuntimeError(
            f"LLM did not return valid JSON.\nRaw output:\n{raw_text}"
        ) from e
