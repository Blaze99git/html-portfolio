import json
from paho.mqtt.client import Client
from master_router.master_router import process_alert

MQTT_BROKER = "localhost"
MQTT_PORT = 1885
INPUT_TOPIC = "highbyte/alerts/context"
OUTPUT_TOPIC = "highbyte/alerts/diagnosis"

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("[MQTT] Connected")
        client.subscribe(INPUT_TOPIC)
    else:
        print("[MQTT] Connection failed", rc)

def on_message(client, userdata, msg):
    try:
        payload = json.loads(msg.payload.decode())
        print("\n[MQTT IN]", payload)

        result = process_alert(payload)

        client.publish(
            OUTPUT_TOPIC,
            json.dumps(result),
            qos=1
        )

        print("[MQTT OUT]", result)

    except Exception as e:
        print("[MQTT ERROR]", e)

def start_mqtt():
    client = Client()
    client.on_connect = on_connect
    client.on_message = on_message

    client.connect(MQTT_BROKER, MQTT_PORT, 60)
    client.loop_forever()
