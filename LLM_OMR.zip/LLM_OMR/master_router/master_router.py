from utils.csv_loader import load_csv
from master_router.ollama_client import ask_ollama

def process_alert(alert, trends):
    return ask_ollama(
        alert_name=alert["alert_name"],
        asset_id=alert["asset_id"],
        trends=trends
    )

def main():
    alerts = load_csv("data/alerts.csv")
    trends = load_csv("data/trends.csv")

    for alert in alerts:
        alert_trends = [
            {"metric": t["metric"], "value": float(t["value"])}
            for t in trends if t["alert_id"] == alert["alert_id"]
        ]

        print(f"\nALERT: {alert['alert_name']} ({alert['asset_id']})")
        result = process_alert(alert, alert_trends)
        print(result)

if __name__ == "__main__":
    main()
